# Aman Kaura — Portfolio

This is the source for my personal site, built for GitHub Pages.

## Local edit
Just edit `index.html`. Projects live in `projects.json` when ready.
